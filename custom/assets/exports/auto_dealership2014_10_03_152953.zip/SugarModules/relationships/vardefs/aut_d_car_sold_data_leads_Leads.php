<?php
// created: 2014-10-03 15:29:53
$dictionary["Lead"]["fields"]["aut_d_car_sold_data_leads"] = array (
  'name' => 'aut_d_car_sold_data_leads',
  'type' => 'link',
  'relationship' => 'aut_d_car_sold_data_leads',
  'source' => 'non-db',
  'module' => 'aut_d_car_sold_data',
  'bean_name' => 'aut_d_car_sold_data',
  'side' => 'right',
  'vname' => 'LBL_AUT_D_CAR_SOLD_DATA_LEADS_FROM_AUT_D_CAR_SOLD_DATA_TITLE',
);
